
#### This directory contains the CHIP.v we use to implement BPU

#### We implement two kinds of BPU ( 2-bit and 2-level) and compred the performance with ex-branch.

#### Our best BPU is in the directory rtl and syn.
